package com.utopo.sdk.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferSign {
    private String collectionHash;
    private String assetHash;
    private String operation;
    private String toAddress;
}
