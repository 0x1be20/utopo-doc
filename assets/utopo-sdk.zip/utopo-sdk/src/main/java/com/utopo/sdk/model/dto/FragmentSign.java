package com.utopo.sdk.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FragmentSign {
    private String operation;
    private String collectionHash;
    private String assetHash;
    private Integer fragmentSize;
    private String toAddress;
    private String[] fragmentImages;
}
