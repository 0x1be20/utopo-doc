package com.utopo.sdk.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Collection {
    private Integer id;
    private String image;
    private String name;
    private String description;
    private Long createTime;
    private Long updateTime;
    private Integer status;
    private String address;
    private Long developerId;
    private String owner;
    private String collectionHash;
}
