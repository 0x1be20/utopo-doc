package com.utopo.sdk.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Asset {
    private Integer id;
    private String image;
    private String description;
    private Long createTime;
    private Long updateTime;
    private Integer status;
    private Integer collectionId;
    private String assetHash;
    private String owner;
    private Integer parentId;

    private Collection assetCollection;
    private List<Attribute> attributes;
}
