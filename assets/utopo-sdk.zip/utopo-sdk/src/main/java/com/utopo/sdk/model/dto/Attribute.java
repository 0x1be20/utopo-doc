package com.utopo.sdk.model.dto;

import lombok.Data;

@Data
public class Attribute {
    private Long id;
    private Long collectionId;
    private Long assetId;
    private String attributeKey;
    private String attributeValue;
    private Long createTime;
}
