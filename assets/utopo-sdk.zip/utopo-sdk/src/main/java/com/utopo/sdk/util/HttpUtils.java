package com.utopo.sdk.util;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.util.StringUtils;

import com.utopo.sdk.exception.BizException;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Slf4j
public class HttpUtils {

    private static OkHttpClient createOkHttpClient() {
        final OkHttpClient.Builder builder = new OkHttpClient.Builder();
        return builder
                .retryOnConnectionFailure(true)
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(90, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    public static String get(String url) {
        OkHttpClient httpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .get()
                .url(url)
                .build();
        return callRemote(url, httpClient, request);
    }

    public static String post(String url, String requestBody) {
        log.info(url);
        log.info(requestBody);
        OkHttpClient httpClient = new OkHttpClient();
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), requestBody);
        Request request = new Request.Builder().header("Content-Type", "application/json").url(url).post(body)
                .build();
        return callRemote(url, httpClient, request);
    }

    private static String callRemote(String url, OkHttpClient httpClient, Request request) {
        Call call = httpClient.newCall(request);
        String respStr = null;

        try {
            ResponseBody responseBody = call.execute().body();
            if (responseBody != null) {
                respStr = responseBody.string();
            }
        } catch (IOException e) {
            log.error("调用{}发生异常，异常原因{}", url, e.getMessage());
            throw new BizException(String.format("远程调用【%s】发生异常，原因【%s】", url, e.getMessage()));
        }

        if (!StringUtils.hasLength(respStr)) {
            throw new BizException(String.format("远程调用【%s】发生异常，原因【%s】", url, "respStr is null"));
        }
        log.info("调用{}返回数据为:{}",url,respStr);
        return respStr;
    }

    public static void delay(long milliSeconds) {
        try {
            TimeUnit.MILLISECONDS.sleep(milliSeconds);
        } catch (InterruptedException e) {}
    }

    /**
     * 随机延时1s-2s
     */
    public static void randomDelayForWax() {
        int max = 1000;
        int min = 2000;
        long randomNum = Math.round(Math.random() * (max - min) + min);
        delay(randomNum);
    }
}
