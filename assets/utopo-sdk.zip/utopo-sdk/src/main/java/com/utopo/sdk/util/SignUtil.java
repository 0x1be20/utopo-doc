package com.utopo.sdk.util;

import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.encoders.Hex;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.Hash;
import org.web3j.crypto.Sign;

@Slf4j
public class SignUtil {

    public static String sign(Object signObject, String privateKey) {
        JSONConfig jsonConfig = new JSONConfig();
        jsonConfig.setOrder(true);
        String operateName = JSONUtil.toJsonStr(signObject, jsonConfig);
        byte[] contentHashBytes = Hash.sha3(operateName.getBytes());

        Credentials credentials = Credentials.create(privateKey);
        Sign.SignatureData signMessage = Sign.signPrefixedMessage(contentHashBytes, credentials.getEcKeyPair());
        return "0x" + Hex.toHexString(signMessage.getR()) + "_" + Hex.toHexString(signMessage.getS()) + "_"  + Hex.toHexString(signMessage.getV());
    }

}
