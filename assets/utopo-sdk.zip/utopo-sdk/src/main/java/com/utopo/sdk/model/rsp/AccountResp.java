package com.utopo.sdk.model.rsp;

import com.utopo.sdk.model.dto.KeyPair;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountResp {
    private Integer code;
    private KeyPair data;
    private String message;
}
