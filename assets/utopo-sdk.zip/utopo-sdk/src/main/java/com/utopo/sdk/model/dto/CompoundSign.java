package com.utopo.sdk.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompoundSign {
    private String operation;
    private List<String> fragmentHashs;
    private String toAddress;
}
