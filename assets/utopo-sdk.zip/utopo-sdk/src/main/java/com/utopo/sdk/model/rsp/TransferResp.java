package com.utopo.sdk.model.rsp;

import com.utopo.sdk.model.dto.Asset;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferResp {
    private Integer code;
    private Asset data;
    private String message;
}
