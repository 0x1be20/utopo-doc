package com.utopo.sdk.model.req;

import com.utopo.sdk.model.dto.FragmentSign;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FragmentReq {
    private FragmentSign signRequest;
    private String owner;
    private String message;
}
