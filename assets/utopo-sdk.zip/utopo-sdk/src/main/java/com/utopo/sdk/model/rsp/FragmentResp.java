package com.utopo.sdk.model.rsp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.utopo.sdk.model.dto.Asset;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FragmentResp {
    private Integer code;
    private List<Asset> data;
    private String message;
}
