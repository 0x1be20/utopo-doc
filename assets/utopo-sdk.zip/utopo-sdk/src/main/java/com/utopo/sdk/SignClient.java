package com.utopo.sdk;

import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.utopo.sdk.exception.BizException;
import com.utopo.sdk.model.dto.*;
import com.utopo.sdk.model.req.CompoundReq;
import com.utopo.sdk.model.req.FragmentReq;
import com.utopo.sdk.model.req.TransferReq;
import com.utopo.sdk.util.HttpUtils;
import com.utopo.sdk.util.SignUtil;

import org.springframework.util.StringUtils;

import java.util.List;

public class SignClient {
    private static final String DEV_BASE_URI = "http://proxy.pingolab.com/blockchainfit";
    private static final String PROD_BASE_URI = "http://proxy.pingolab.com/blockchainfit";

    private String baseUri;

    public SignClient(String mode, String baseUri){
        this.baseUri = baseUri;

        if (!StringUtils.hasLength(baseUri)) {
            if ("dev".equals(mode)) {
                this.baseUri = DEV_BASE_URI;
            } else {
                this.baseUri = PROD_BASE_URI;
            }
        }
    }

    public KeyPair createAccount(){
        try {
            String result = HttpUtils.post(this.baseUri + "/sign/account", null);
            JSONObject jsonObject = JSON.parseObject(result);
            Object data = jsonObject.get("data");
            return JSON.parseObject(JSON.toJSONString(data), KeyPair.class);
        } catch (Exception e) {
            throw new BizException("createAccount fail!", e);
        }
    }

    public Asset transfer(String assetHash, String toAddress, KeyPair pair){
        try {
            TransferSign postData = new TransferSign("", assetHash, "transfer", toAddress);
            String signature = SignUtil.sign(postData, pair.getPrivateKey());

            TransferReq transferData = new TransferReq(postData, pair.getAddress(), signature);
            String transferBody = JSONUtil.toJsonStr(transferData, new JSONConfig().setOrder(true));
            String result = HttpUtils.post(this.baseUri + "/asset/transfer", transferBody);
            JSONObject jsonObject = JSON.parseObject(result);
            Object data = jsonObject.get("data");
            return JSON.parseObject(JSON.toJSONString(data), Asset.class);
        } catch (Exception e) {
            throw new BizException("transfer fail!", e);
        }

    }

    public List<Asset> fragment(String assetHash, int fragmentSize, String[] fragmentImages, String toAddress, KeyPair pair){
        try {
            FragmentSign postData = new FragmentSign("fragment", "", assetHash, fragmentSize, toAddress, fragmentImages);
            String signature = SignUtil.sign(postData, pair.getPrivateKey());

            FragmentReq fragmentData = new FragmentReq(postData, pair.getAddress(), signature);
            String fragmentPostData = JSONUtil.toJsonStr(fragmentData, new JSONConfig().setOrder(true));
            String result = HttpUtils.post(this.baseUri + "/asset/fragment", fragmentPostData);
            JSONObject jsonObject = JSON.parseObject(result);
            Object data = jsonObject.get("data");
            JSONArray jsonArray = JSONArray.parseArray(JSON.toJSONString(data));
            return jsonArray.toJavaList(Asset.class);
        } catch (Exception e) {
            throw new BizException("fragment fail!", e);
        }
    }

    public Asset compound(List<String> fragmentHashs,String toAddress,KeyPair pair){
        try {
            CompoundSign postData = new CompoundSign("compound", fragmentHashs, toAddress);
            String signature = SignUtil.sign(postData, pair.getPrivateKey());

            CompoundReq compoundData = new CompoundReq(postData, pair.getPrivateKey(), signature);
            String compoundPostData = JSONUtil.toJsonStr(compoundData, new JSONConfig().setOrder(true));
            String result = HttpUtils.post(this.baseUri + "/asset/compound", compoundPostData);
            JSONObject jsonObject = JSON.parseObject(result);
            Object data = jsonObject.get("data");
            return JSON.parseObject(JSON.toJSONString(data), Asset.class);
        } catch (Exception e) {
            throw new BizException("fragment fail!", e);
        }
    }

    public List<Asset> getAssetsOfOwner(String collectionHash, String ownerAddress){
        try {
            String url = this.baseUri + String.format("/asset/query/collection/asset?collectionHash=%s&owner=%s", collectionHash, ownerAddress);
            String result = HttpUtils.get(url);
            JSONObject jsonObject = JSON.parseObject(result);
            Object data = jsonObject.get("data");
            JSONArray jsonArray = JSONArray.parseArray(JSON.toJSONString(data));
            return jsonArray.toJavaList(Asset.class);
        } catch (Exception e) {
            throw new BizException("fragment fail!", e);
        }
    }
}
