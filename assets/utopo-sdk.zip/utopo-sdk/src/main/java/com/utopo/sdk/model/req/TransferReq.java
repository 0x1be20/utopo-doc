package com.utopo.sdk.model.req;

import com.utopo.sdk.model.dto.TransferSign;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferReq {
    private TransferSign signRequest;
    private String owner;
    private String message;
}
